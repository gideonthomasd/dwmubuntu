#ifndef GTKCONF_H
#define GTKCONF_H

#include "sbuf.h"

void gtkconf_get(struct sbuf *buf, const char *key);

#endif /* GTKCONF_H */
