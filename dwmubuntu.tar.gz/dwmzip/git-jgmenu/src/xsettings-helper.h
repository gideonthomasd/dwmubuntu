#ifndef XSETTINGS_HELPER_H
#define XSETTINGS_HELPER_H

#include <stdio.h>
#include <stdlib.h>

#include "sbuf.h"

void xsettings_get(struct sbuf *s, const char *key);

#endif /* XSETTINGS_HELPER_H */
