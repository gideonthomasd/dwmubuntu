#ifndef WORKAREA_H
#define WORKAREA_H

void workarea_set_margin(void);
void workarea_set_panel_pos(void);

#endif /* WORKAREA_H */
