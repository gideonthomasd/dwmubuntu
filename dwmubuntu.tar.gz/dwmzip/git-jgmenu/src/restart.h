#ifndef RESTART_H
#define RESTART_H

void restart_init(int argc, char **argv);
void restart(void);

#endif /* RESTART_H */
