#ifndef XPM_LOADER_H
#define XPM_LOADER_H

#include <cairo.h>

cairo_surface_t *get_xpm_icon(const char *filename);

#endif
