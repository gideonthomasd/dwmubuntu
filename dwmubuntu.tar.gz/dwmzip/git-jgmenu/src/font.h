#ifndef FONT_H
#define FONT_H

char *font_get(void);
void font_set(void);
void font_cleanup(void);

#endif /* FONT_H */
