#ifndef BL_H
#define BL_H

#include "sbuf.h"

void bl_tint2file(struct sbuf *tint2_file);

#endif /* BL_H */
