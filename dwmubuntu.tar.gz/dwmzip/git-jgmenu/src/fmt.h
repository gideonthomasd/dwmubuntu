#ifndef FMT_H
#define FMT_H

#include "sbuf.h"

void fmt_name(struct sbuf *buf, const char *name, const char *generic_name);

#endif /* FMT_H */
