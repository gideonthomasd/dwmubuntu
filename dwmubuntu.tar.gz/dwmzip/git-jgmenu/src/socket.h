#ifndef SOCKET_H
#define SOCKET_H

#define SOCKET_BUF_SIZE 4096

char *tint2_socket_path(void);

#endif
