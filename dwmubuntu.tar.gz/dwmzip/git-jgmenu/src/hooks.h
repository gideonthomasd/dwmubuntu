#ifndef JGMENU_HOOKS_H
#define JGMENU_HOOKS_H

void hooks_init(void);
void hooks_check(void);
void hooks_cleanup(void);

#endif /* JGMENU_HOOKS_H */
