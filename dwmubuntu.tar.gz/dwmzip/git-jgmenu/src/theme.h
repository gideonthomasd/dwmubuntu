#ifndef THEME_H
#define THEME_H

#include "sbuf.h"

void theme_set(struct sbuf *theme);

#endif /* THEME_H */
