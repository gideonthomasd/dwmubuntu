#ifndef LOCKFILE_H
#define LOCKFILE_H

void lockfile_unlink(void);
void lockfile_init(void);

#endif /* LOCKFILE_H */
