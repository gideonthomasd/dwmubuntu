#ifndef PROG_FINDER_H
#define PROG_FINDER_H

int isprog(const char *filename);

#endif /* PROG_FINDER_H */
