#ifndef BACK_H
#define BACK_H

char *back_string(void);

#endif /* BACK_H */
