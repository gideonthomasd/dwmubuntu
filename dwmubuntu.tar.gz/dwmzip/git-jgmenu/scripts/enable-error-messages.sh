#!/bin/sh

# This file is designed to be sourced before running jgmenu
# Uncomment the variable which controls the message(s) you wish to see

# Display screen info for each monitor
#export JGMENU_SCREEN_INFO=1

# Show which config file is being used
#export JGMENU_CONFIG_FILE_INFO=1

# Display workarea info including alignment/margin deduced from it
#export JGMENU_WORKAREA_INFO=1
