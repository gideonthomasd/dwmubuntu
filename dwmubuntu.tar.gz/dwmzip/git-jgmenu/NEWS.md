# Release Notes

## All releases

[docs/relnotes/](docs/relnotes/)

## Recent releases

| Date       | Release Notes                     |
|------------|-----------------------------------|
| 2020-05-19 | [v4.2.1](docs/relnotes/4.2.1.txt) |
| 2020-05-06 | [v4.2.0](docs/relnotes/4.2.0.txt) |
| 2020-03-02 | [v4.1.0](docs/relnotes/4.1.0.txt) |
| 2020-02-02 | [v4.0.2](docs/relnotes/4.0.2.txt) |
| 2020-01-19 | [v4.0.1](docs/relnotes/4.0.1.txt) |

