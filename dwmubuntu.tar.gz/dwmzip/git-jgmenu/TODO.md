See [roadmap](https://jgmenu.github.io/roadmap.html)

