#!/bin/bash

mkdir -p ~/st-transparency
mkdir -p ~/dwm-6.2
mkdir -p ~/slstatus

mkdir -p ~/.config/rofi
mkdir -p ~/.config/jgmenu

mkdir -p ~/.fonts

cd dwm-6.2
cp -r * ~/dwm-6.2
cd ..

cd st-transparency
cp -r * ~/st-transparency
cd ..

cd slstatus
cp -r * ~/slstatus
cd ..

cd rofi
cp -r * ~/.config/rofi
cd ..

cd jgmenu
cp -r * ~/.config/jgmenu
cd ..

cd fonts
cp -r * ~/.fonts
cd ..

#cd git-jgmenu
#dpkg-buildpackage -tc -b -us -uc
#sudo dpkg -i jgmenu_4.2.1-1_amd64.deb

echo "sudo make install in dwm-6.2, st-transparency, slstatus"
echo "sudo dpkg -i jgmenu_4.2.1-1_amd64.deb in this directory"

cp xinitrc ~/.xinitrc
