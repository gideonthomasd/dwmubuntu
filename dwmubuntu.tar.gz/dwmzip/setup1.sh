#!/bin/bash

sudo apt update && sudo apt upgrade -y

sudo apt -y install xorg stterm suckless-tools build-essential libx11-dev libxinerama-dev libxft-dev git vim libwebkit2gtk-4.0-dev feh

sudo apt -y install geany lxappearance lxsession xcompmgr debhelper librsvg2-dev libmenu-cache-dev libxfce4panel-2.0-dev sxhkd thunar firefox xinit
echo "Reboot system.  Do sudo apt remove gdm3 - or perhaps remove lightdm"

#sudo apt remove gdm3

#sudo apt -y install geany lxappearance lxsession xcompmgr debhelper librsvg2-dev libmenu-cache-dev libxfce4panel-2.0-dev

