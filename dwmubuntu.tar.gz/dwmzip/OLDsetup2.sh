#!/bin/bash

sudo apt -y install geany lxappearance lxsession xcompmgr debhelper librsvg2-dev libmenu-cache-dev libxfce4panel-2.0-dev sxhkd thunar firefox xinit

